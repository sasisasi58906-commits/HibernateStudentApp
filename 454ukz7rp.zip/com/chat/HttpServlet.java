package com.chat;

/**
 * HttpServlet
 */
public class HttpServlet {

}
