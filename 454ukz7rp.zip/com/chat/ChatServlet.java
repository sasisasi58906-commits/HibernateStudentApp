package com.chat;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/chat")
public class ChatServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String sender = (String) session.getAttribute("username");
        String receiver = request.getParameter("receiver");
        String message = request.getParameter("message");

        response.setContentType("text/plain;charset=UTF-8");

        if (sender == null) {
            response.getWriter().write("Please login first");
            return;
        }

        if (receiver == null || message == null ||
                receiver.trim().isEmpty() ||
                message.trim().isEmpty()) {

            response.getWriter().write("Invalid message");
            return;
        }

        try (Connection con = DBConnection.getConnection()) {

            String sql =
                    "INSERT INTO messages(sender, receiver, message) " +
                    "VALUES (?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, sender);
            ps.setString(2, receiver);
            ps.setString(3, message);

            ps.executeUpdate();

            response.getWriter().write("success");

        } catch (Exception e) {

            e.printStackTrace();
            response.getWriter().write("error");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String sender = (String) session.getAttribute("username");
        String receiver = request.getParameter("receiver");

        response.setContentType("text/html;charset=UTF-8");

        if (sender == null || receiver == null) {
            return;
        }

        try (Connection con = DBConnection.getConnection()) {

            String sql =
                    "SELECT sender, receiver, message, message_time " +
                    "FROM messages " +
                    "WHERE (sender = ? AND receiver = ?) " +
                    "OR (sender = ? AND receiver = ?) " +
                    "ORDER BY message_time ASC";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, sender);
            ps.setString(2, receiver);
            ps.setString(3, receiver);
            ps.setString(4, sender);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                String msgSender = rs.getString("sender");
                String msgReceiver = rs.getString("receiver");
                String message = rs.getString("message");
                String time = rs.getString("message_time");

                message = message
                        .replace("&", "&amp;")
                        .replace("<", "&lt;")
                        .replace(">", "&gt;")
                        .replace("\"", "&quot;");

                response.getWriter().println(
                    "<div class='message'>" +
                    "<b>" + msgSender + "</b> → " +
                    "<b>" + msgReceiver + "</b><br>" +
                    message +
                    "<span class='time'>" + time + "</span>" +
                    "</div>"
                );
            }

        } catch (Exception e) {

            e.printStackTrace();
            response.getWriter().println("Error loading messages");
        }
    }
}