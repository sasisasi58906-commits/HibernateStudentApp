package com.chat;

/**
 * WebServlet
 */
public @interface WebServlet {

}
