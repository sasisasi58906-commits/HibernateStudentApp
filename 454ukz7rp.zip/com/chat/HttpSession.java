package com.chat;

/**
 * HttpSession
 */
public class HttpSession {

}
