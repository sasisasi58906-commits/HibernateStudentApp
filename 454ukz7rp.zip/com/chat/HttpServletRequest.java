package com.chat;

/**
 * HttpServletRequest
 */
public class HttpServletRequest {

}
